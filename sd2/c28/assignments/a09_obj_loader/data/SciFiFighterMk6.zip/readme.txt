From:
https://www.turbosquid.com/3d-models/free-spaceship-fighter-3d-model/727670
