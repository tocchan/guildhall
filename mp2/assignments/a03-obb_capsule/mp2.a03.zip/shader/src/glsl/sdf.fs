#version 450

#include "inc/math.glsl"

// constants
layout(set = 2, binding = 2) uniform sampler2D ALBEDO_MAP; // image backed sampler;  (fragment only)

//  inputs
layout(location = 0) in vec4 fi_color;
layout(location = 1) in vec2 fi_uv; 

// outputs
layout(location = 0) out vec4 out_color;

// fragment shader
void main() 
{
    float alpha = texture( ALBEDO_MAP, fi_uv ).x;
   
   if (alpha < .45f) {
      discard; 
   }

   alpha = RangeMap( alpha, .49f, .5f, 0.0f, 1.0f ); 
   out_color = vec4( fi_color.xyz, fi_color.w * alpha ); 
}