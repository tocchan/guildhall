#version 450

// constants
layout(set = 2, binding = 2) uniform sampler2D ALBEDO_MAP; // image backed sampler;  (fragment only)

//  inputs
layout(location = 0) in vec4 fi_color;
layout(location = 1) in vec2 fi_uv; 

// outputs
layout(location = 0) out vec4 out_color;

// fragment shader
void main() 
{
    vec4 albedo = texture( ALBEDO_MAP, fi_uv ); 
    out_color = fi_color * albedo; 
}