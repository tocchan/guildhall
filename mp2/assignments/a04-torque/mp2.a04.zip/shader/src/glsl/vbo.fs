#version 450

//  inputs
layout(location = 0) in vec4 fi_color;

// outputs
layout(location = 0) out vec4 out_color;

// fragment shader
void main() 
{
    out_color = fi_color;
}